## Personalized Path Generation 
Kenny Chung, Maryam Amosu, Travis Latchman, Christal Oji, Folahan Koleosho, Aashi Mendpara, Luke Long, Clara Moore

Our project aims to develop methods for personalized content delivery. We will use a web scraper to collect website URLs that are related to a user's inputted keyword. We will then use topic modeling to relate topics concerning the keyword. Lastly, we will format the YAML files for the content into a personalized, generated course for the user. 
